# Decision Review

Downstream app package that composes downloaded societal-analysis refs. It
subscribes to the simulated decision-signal channel produced by Society
Sentinel.
