def create_app():
    return {'service': 'review'}
