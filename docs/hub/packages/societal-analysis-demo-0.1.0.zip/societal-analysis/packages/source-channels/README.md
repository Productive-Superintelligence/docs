# Source Channels

Deterministic source and output channels for the societal-analysis demo.
The package declares synthetic finance, business, economics, geopolitics,
social/culture, market time-series, analyst-record, aggregate-report, and
decision-signal resources. It is dummy data only.
