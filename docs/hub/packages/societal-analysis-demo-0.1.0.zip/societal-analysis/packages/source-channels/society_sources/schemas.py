from pydantic import BaseModel


class SourceRecord(BaseModel):
    domain: str
    value: object | None = None


class AnalystRecord(BaseModel):
    domain: str
    runtime: str
    summary: str
    score: float


class AggregateReport(BaseModel):
    domains: list[str]
    source_record_count: int
    summary: str


class DecisionSignal(BaseModel):
    signal: str
    reason: str
    confidence: float
