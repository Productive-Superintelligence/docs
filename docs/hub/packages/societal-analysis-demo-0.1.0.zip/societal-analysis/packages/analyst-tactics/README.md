# Analyst Tactics

Deterministic LLLM analyst tactics over synthetic fixture data. The package
contains a plain Python analyst, a Pydantic-AI-style analyst with tool metadata,
and a native-runtime-style analyst. No provider key is required.
