def create_finance_app():
    return {"service": "finance"}


def create_tool_app():
    return {"service": "tool"}


def create_native_app():
    return {"service": "native"}
