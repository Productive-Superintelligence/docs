from pydantic import BaseModel


class AnalystInput(BaseModel):
    domain: str
    records: list[dict]


class AnalystOutput(BaseModel):
    domain: str
    runtime: str
    summary: str
    score: float
