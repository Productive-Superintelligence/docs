class FinanceBaseline:
    def run(self, input_value, *, context=None):
        records = input_value["records"]
        return {
            "domain": input_value["domain"],
            "runtime": "python",
            "summary": f"baseline:{records[0]['domain']}",
            "score": float(len(records)),
        }


class ToolAugmentedAnalyst:
    def run(self, input_value, *, context=None):
        records = input_value["records"]
        score = self.score_indicator(records[0])
        return {
            "domain": input_value["domain"],
            "runtime": "pydantic-ai",
            "summary": f"tool-score:{score}",
            "score": score,
        }

    def score_indicator(self, record):
        return float(record.get("value", 0)) / 10.0


class NativeDialogAnalyst:
    def run(self, input_value, *, context=None):
        records = input_value["records"]
        return {
            "domain": input_value["domain"],
            "runtime": "native",
            "summary": f"dialog-reviewed:{records[0]['domain']}",
            "score": 0.0,
        }
