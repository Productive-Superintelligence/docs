# Societal Analysis Demo

This bundle contains deterministic PSI packages for the public PsiWeb demo:

- `source-channels`
- `analyst-tactics`
- `market-analyst`
- `society-sentinel`
- `decision-review`

It is synthetic fixture data only. It is not financial, political, cultural,
trading, or operational advice.

## Setup

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -U pip
python -m pip install "lllm-core[client,server]" sssn psihub
python run_society_fixture.py
```

The script validates the downloaded packages, runs deterministic local tactics,
writes raw and derived records to an SSSN local store, and prints a JSON
summary.
