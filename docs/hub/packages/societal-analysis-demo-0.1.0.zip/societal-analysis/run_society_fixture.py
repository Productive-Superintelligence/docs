from __future__ import annotations

import asyncio
import json
from pathlib import Path

from lllm import RemoteTactic, TacticResolver, as_tactic
from lllm.services import create_service_app
from sssn import Event, LocalStore

from psihub import import_entrypoint, load_manifest, validate_package


ROOT = Path(__file__).resolve().parent
PACKAGES = ROOT / "packages"


def main() -> None:
    source = PACKAGES / "source-channels"
    tactics = PACKAGES / "analyst-tactics"
    sentinel = PACKAGES / "society-sentinel"
    market = PACKAGES / "market-analyst"
    review = PACKAGES / "decision-review"
    for package in (source, tactics, market, sentinel, review):
        report = validate_package(package)
        if not report.ok:
            raise SystemExit(f"{package.name} failed validation: {report.issues}")

    source_manifest = load_manifest(source)
    tactics_manifest = load_manifest(tactics)
    sentinel_manifest = load_manifest(sentinel)
    store = LocalStore(ROOT / ".sssn-society-demo")
    for name in (
        "finance_ticks",
        "economic_indicators",
        "social_culture",
        "analyst_records",
        "aggregate_reports",
        "decision_signals",
    ):
        store.create_channel({"name": name, "form": "log"})

    raw_events = [
        store.append_event(
            Event(
                channel="finance_ticks",
                source="fixture",
                kind="finance",
                payload={"domain": "finance", "symbol": "ACME", "value": 101.2},
                correlation_id="society-run",
            )
        ),
        store.append_event(
            Event(
                channel="economic_indicators",
                source="fixture",
                kind="economics",
                payload={"domain": "economics", "indicator": "cpi", "value": 2.4},
                correlation_id="society-run",
            )
        ),
        store.append_event(
            Event(
                channel="social_culture",
                source="fixture",
                kind="culture",
                payload={"domain": "culture", "topic": "tooling", "sentiment": "steady"},
                correlation_id="society-run",
            )
        ),
    ]

    tactic_specs = (
        ("finance_baseline", "FinanceBaseline", [raw_events[0]]),
        ("tool_augmented", "ToolAugmentedAnalyst", [raw_events[1]]),
        ("native_dialog", "NativeDialogAnalyst", [raw_events[2]]),
    )
    resolver = TacticResolver()
    for name, class_name, _selected in tactic_specs:
        cls = import_entrypoint(
            f"society_analysts.tactics:{class_name}",
            base_dir=tactics,
        )
        resolver.register(
            tactics_manifest.ref("tactic", name),
            as_tactic(
                cls().run,
                name=name,
                input_type=dict,
                output_type=dict,
                package_ref=tactics_manifest.ref("tactic", name),
            ),
        )

    analysis_events = []
    for name, _class_name, selected_events in tactic_specs:
        output = resolver.run(
            tactics_manifest.ref("tactic", name),
            {
                "domain": selected_events[0].payload["domain"],
                "records": [event.payload for event in selected_events],
            },
        )
        analysis_events.append(
            store.append_event(
                Event(
                    channel="analyst_records",
                    source=name,
                    kind="analysis",
                    payload=output,
                    correlation_id="society-run",
                    parent_ids=tuple(event.id for event in selected_events),
                )
            )
        )

    aggregate_cls = import_entrypoint(
        "society_sentinel.tactics:AggregateReport",
        base_dir=sentinel,
    )
    decision_cls = import_entrypoint(
        "society_sentinel.tactics:DecisionSignal",
        base_dir=sentinel,
    )
    pipeline_cls = import_entrypoint(
        "society_sentinel.tactics:DecisionPipeline",
        base_dir=sentinel,
    )
    aggregate_ref = sentinel_manifest.ref("tactic", "aggregate_report")
    decision_ref = sentinel_manifest.ref("tactic", "simulate_decision")
    pipeline_ref = sentinel_manifest.ref("tactic", "decision_pipeline")
    aggregate_tactic = as_tactic(
        aggregate_cls().run,
        name="aggregate_report",
        input_type=dict,
        output_type=dict,
        package_ref=aggregate_ref,
    )
    decision_tactic = as_tactic(
        decision_cls().run,
        name="simulate_decision",
        input_type=dict,
        output_type=dict,
        package_ref=decision_ref,
    )
    resolver.register(aggregate_ref, aggregate_tactic)
    resolver.register(decision_ref, decision_tactic)
    pipeline_tactic = as_tactic(
        pipeline_cls(resolver, decision_ref).run,
        name="decision_pipeline",
        input_type=dict,
        output_type=dict,
        package_ref=pipeline_ref,
    )
    resolver.register(
        pipeline_ref,
        pipeline_tactic,
    )

    app = create_service_app(
        {
            "aggregate_report": aggregate_tactic,
            "simulate_decision": decision_tactic,
            "decision_pipeline": pipeline_tactic,
        },
        title="Society Sentinel Fixture",
    )
    transport = __import__("httpx").ASGITransport(app=app)
    remote = TacticResolver()
    remote.register(
        aggregate_ref,
        RemoteTactic(
            "http://sentinel/tactics/aggregate_report",
            name="aggregate_report",
            input_type=dict,
            output_type=dict,
            async_transport=transport,
        ),
    )
    remote.register(
        pipeline_ref,
        RemoteTactic(
            "http://sentinel/tactics/decision_pipeline",
            name="decision_pipeline",
            input_type=dict,
            output_type=dict,
            async_transport=transport,
        ),
    )
    report = asyncio.run(
        remote.arun(
            aggregate_ref,
            {"records": [event.payload for event in analysis_events]},
        )
    )
    report_event = store.append_event(
        Event(
            channel="aggregate_reports",
            source="aggregate_report",
            kind="report",
            payload=report,
            correlation_id="society-run",
            parent_ids=tuple(event.id for event in analysis_events),
        )
    )
    decision = asyncio.run(remote.arun(pipeline_ref, {"report": report_event.payload}))
    decision_event = store.append_event(
        Event(
            channel="decision_signals",
            source="decision_pipeline",
            kind="decision",
            payload=decision,
            correlation_id="society-run",
            parent_ids=(report_event.id,),
        )
    )
    store.put_snapshot(
        {
            "name": "latest_report",
            "channel": "aggregate_reports",
            "value": report_event.payload,
            "source_event_id": report_event.id,
            "metadata": {
                "source_package": source_manifest.package.identifier,
                "analyst_package": tactics_manifest.package.identifier,
            },
        }
    )
    print(
        json.dumps(
            {
                "raw_records": len(raw_events),
                "analysis_records": len(analysis_events),
                "aggregate_domains": report_event.payload["domains"],
                "decision": decision_event.payload,
                "latest_report_snapshot": store.get_snapshot("latest_report").name,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
