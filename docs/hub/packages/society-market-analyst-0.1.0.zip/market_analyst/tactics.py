class MarketBrief:
    def run(self, input_value, *, context=None):
        return {
            "domain": "market",
            "runtime": "python",
            "summary": "market fixture",
            "score": 1.0,
        }
