def create_app():
    return {'service': 'market'}
