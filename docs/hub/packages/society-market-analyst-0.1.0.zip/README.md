# Market Analyst

Combined package with one local tactic and SSSN channel declarations. It is
used to test mixed LLLM/SSSN package composition over deterministic data.
