class AggregateReport:
    def run(self, input_value, *, context=None):
        records = input_value["records"]
        return {
            "domains": [record["domain"] for record in records],
            "source_record_count": len(records),
            "summary": " | ".join(record["summary"] for record in records),
        }


class DecisionSignal:
    def run(self, input_value, *, context=None):
        return {
            "signal": "hold",
            "reason": "simulation only",
            "confidence": 0.0,
        }


class DecisionPipeline:
    def __init__(self, resolver, decision_ref):
        self.resolver = resolver
        self.decision_ref = decision_ref

    def run(self, input_value, *, context=None):
        return self.resolver.run(self.decision_ref, input_value)
