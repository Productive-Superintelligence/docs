def create_app():
    return {'service': 'sentinel'}
